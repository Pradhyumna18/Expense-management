export const accountNameChange="ACCOUNT_NAME_CHANGE"
export const accountBalanceChange="ACCOUNT_BALANCE_CHANGE"
export const addAccount="ADD_ACCOUNT"
export const divClicked="DIV_CLICKED"
export const onDivClick="ON_DIV_CLICK"
export const fetchTransaction="GET_TRANSACTION" 
export const getAccount="GET_ACCOUNTS"

