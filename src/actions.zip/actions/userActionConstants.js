export const userNameChange="USER_NAME_CHANGE"
export const passwordChange="PASSSWORD_CHANGE"
export const onSignin="SET_TOKEN"
